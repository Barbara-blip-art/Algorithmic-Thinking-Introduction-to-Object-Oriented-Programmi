"""Orçamento de locação: junta o imóvel, a taxa contratual e a projeção de 12 meses."""
import csv
from decimal import Decimal, ROUND_DOWN

from imoveis import Imovel, dinheiro

MESES_PROJECAO = 12


def formatar_real(valor: Decimal) -> str:
    """Formata em padrão brasileiro: R$ 1.234,56."""
    texto = f"{valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"R$ {texto}"


class Orcamento:
    TAXA_CONTRATUAL = Decimal("2000.00")
    MAX_PARCELAS = 5

    def __init__(self, imovel: Imovel, parcelas_taxa: int):
        if not 1 <= parcelas_taxa <= self.MAX_PARCELAS:
            raise ValueError(f"Parcelas da taxa devem estar entre 1 e {self.MAX_PARCELAS}.")
        self.imovel = imovel
        self.parcelas_taxa = parcelas_taxa

    # --- valores ---
    @property
    def aluguel_mensal(self) -> Decimal:
        return self.imovel.aluguel_mensal()

    def parcelas(self) -> list:
        """Divide a taxa em parcelas; a última absorve a diferença de centavos."""
        base = (self.TAXA_CONTRATUAL / self.parcelas_taxa).quantize(Decimal("0.01"), ROUND_DOWN)
        lista = [base] * (self.parcelas_taxa - 1)
        lista.append(dinheiro(self.TAXA_CONTRATUAL - base * (self.parcelas_taxa - 1)))
        return lista

    def total_12_meses(self) -> Decimal:
        return dinheiro(self.aluguel_mensal * MESES_PROJECAO + self.TAXA_CONTRATUAL)

    # --- saídas ---
    def resumo(self) -> str:
        larg = 52
        linhas = ["=" * larg, "ORÇAMENTO DE LOCAÇÃO - R.M IMÓVEIS".center(larg), "=" * larg,
                  f"Imóvel: {self.imovel.descricao()}", "-" * larg, "ALUGUEL MENSAL"]
        for item in self.imovel.itens_detalhados():
            valor = ("-" + formatar_real(abs(item.valor))) if item.valor < 0 else formatar_real(item.valor)
            linhas.append(f"  {item.descricao:<34}{valor:>14}")
        linhas += ["  " + "-" * (larg - 2),
                   f"  {'Aluguel mensal final':<34} {formatar_real(self.aluguel_mensal):>14}",
                   "-" * larg, "TAXA CONTRATUAL (cobrada à parte do aluguel)",
                   f"  Valor total: {formatar_real(self.TAXA_CONTRATUAL)}"]
        parcelas = self.parcelas()
        if self.parcelas_taxa == 1:
            linhas.append("  Pagamento: à vista (1x)")
        else:
            texto = f"  Parcelamento: {self.parcelas_taxa}x de {formatar_real(parcelas[0])}"
            if parcelas[-1] != parcelas[0]:
                texto += f" (última de {formatar_real(parcelas[-1])})"
            linhas.append(texto)
        linhas += ["-" * larg,
                   f"TOTAL PREVISTO NOS 12 PRIMEIROS MESES: {formatar_real(self.total_12_meses())}",
                   "=" * larg]
        return "\n".join(linhas)

    def projecao_12_meses(self) -> list:
        """Uma linha por mês: aluguel + parcela da taxa (se houver) + total + acumulado."""
        parcelas = self.parcelas()
        acumulado = Decimal("0.00")
        linhas = []
        for mes in range(1, MESES_PROJECAO + 1):
            parcela = parcelas[mes - 1] if mes <= len(parcelas) else Decimal("0.00")
            total = dinheiro(self.aluguel_mensal + parcela)
            acumulado = dinheiro(acumulado + total)
            linhas.append({"mes": mes, "aluguel": self.aluguel_mensal, "parcela_taxa": parcela,
                           "total_mes": total, "acumulado": acumulado})
        return linhas


class ExportadorCSV:
    """Responsável apenas por gravar a projeção em arquivo CSV."""

    CABECALHO = ["Mes", "Aluguel (R$)", "Parcela da taxa contratual (R$)",
                 "Total do mes (R$)", "Acumulado (R$)"]

    @staticmethod
    def _num(v: Decimal) -> str:
        return f"{v:.2f}".replace(".", ",")  # decimal com vírgula, padrão do Excel pt-BR

    def exportar(self, orcamento: Orcamento, caminho: str) -> str:
        # utf-8-sig + ';' para abrir direto no Excel em português
        with open(caminho, "w", newline="", encoding="utf-8-sig") as arq:
            escritor = csv.writer(arq, delimiter=";")
            escritor.writerow(self.CABECALHO)
            for l in orcamento.projecao_12_meses():
                escritor.writerow([l["mes"], self._num(l["aluguel"]), self._num(l["parcela_taxa"]),
                                   self._num(l["total_mes"]), self._num(l["acumulado"])])
        return caminho
