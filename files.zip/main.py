"""RentSmart - Sistema de Orçamento de Locação da R.M Imóveis.

Execute com:  python main.py
"""
from interface import ler_sim_nao, montar_orcamento
from orcamento import ExportadorCSV

ARQUIVO_CSV = "projecao_12_meses.csv"


def main() -> None:
    print("=== RentSmart | R.M Imóveis ===")
    while True:
        orcamento = montar_orcamento()
        print("\n" + orcamento.resumo())
        ExportadorCSV().exportar(orcamento, ARQUIVO_CSV)
        print(f"\nProjeção de 12 meses gravada em '{ARQUIVO_CSV}'.")
        if not ler_sim_nao("\nDeseja fazer outro orçamento?"):
            break
    print("Obrigado por usar o RentSmart!")


if __name__ == "__main__":
    main()
