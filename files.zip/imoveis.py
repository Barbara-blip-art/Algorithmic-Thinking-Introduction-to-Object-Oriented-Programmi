"""Modelos de imóveis da R.M Imóveis.

Cada tipo de imóvel conhece as próprias regras de preço (herança + polimorfismo):
o restante do sistema só chama `aluguel_mensal()` e `itens_detalhados()`,
sem precisar saber de qual tipo de imóvel se trata.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from decimal import Decimal

CENTAVOS = Decimal("0.01")


def dinheiro(valor) -> Decimal:
    """Converte para Decimal com 2 casas (evita erros de float em valores monetários)."""
    return Decimal(str(valor)).quantize(CENTAVOS)


@dataclass(frozen=True)
class ItemOrcamento:
    """Uma linha do orçamento: descrição + valor (negativo para descontos)."""
    descricao: str
    valor: Decimal


class Imovel(ABC):
    """Classe base abstrata: define o 'contrato' que todo imóvel precisa cumprir."""

    TIPO = ""
    ALUGUEL_BASE = Decimal("0")

    @abstractmethod
    def adicionais(self) -> list:
        """Lista de ItemOrcamento com os acréscimos (quartos, garagem, vagas...)."""

    @abstractmethod
    def descricao(self) -> str:
        """Texto curto que descreve o imóvel escolhido."""

    def desconto(self) -> ItemOrcamento | None:
        """Por padrão, imóveis não têm desconto. Subclasses podem sobrescrever."""
        return None

    # --- cálculos comuns, reutilizados por todos os tipos ---
    def subtotal(self) -> Decimal:
        return dinheiro(self.ALUGUEL_BASE + sum((i.valor for i in self.adicionais()), Decimal("0")))

    def valor_desconto(self) -> Decimal:
        d = self.desconto()
        return d.valor if d else Decimal("0.00")

    def aluguel_mensal(self) -> Decimal:
        return dinheiro(self.subtotal() + self.valor_desconto())

    def itens_detalhados(self) -> list:
        """Todas as linhas do cálculo, na ordem: base, adicionais, desconto."""
        itens = [ItemOrcamento(f"Aluguel-base ({self.TIPO})", dinheiro(self.ALUGUEL_BASE))]
        itens += self.adicionais()
        d = self.desconto()
        if d:
            itens.append(d)
        return itens


class ImovelResidencial(Imovel):
    """Casas e apartamentos: 1 ou 2 quartos e vaga de garagem opcional."""

    ADICIONAL_2_QUARTOS = Decimal("0")
    GARAGEM = Decimal("300.00")

    def __init__(self, quartos: int, garagem: bool):
        if quartos not in (1, 2):
            raise ValueError("Quantidade de quartos deve ser 1 ou 2.")
        self.quartos = quartos
        self.garagem = garagem

    def adicionais(self) -> list:
        itens = []
        if self.quartos == 2:
            itens.append(ItemOrcamento("Adicional de 2º quarto", dinheiro(self.ADICIONAL_2_QUARTOS)))
        if self.garagem:
            itens.append(ItemOrcamento("Vaga de garagem", dinheiro(self.GARAGEM)))
        return itens

    def descricao(self) -> str:
        garagem = "com garagem" if self.garagem else "sem garagem"
        return f"{self.TIPO} de {self.quartos} quarto(s), {garagem}"


class Apartamento(ImovelResidencial):
    TIPO = "Apartamento"
    ALUGUEL_BASE = Decimal("700.00")
    ADICIONAL_2_QUARTOS = Decimal("200.00")
    DESCONTO_SEM_CRIANCAS = Decimal("0.05")

    def __init__(self, quartos: int, garagem: bool, tem_criancas: bool):
        super().__init__(quartos, garagem)
        self.tem_criancas = tem_criancas

    def desconto(self) -> ItemOrcamento | None:
        """5% sobre o aluguel já com adicionais, somente para quem não tem crianças."""
        if self.tem_criancas:
            return None
        valor = dinheiro(self.subtotal() * self.DESCONTO_SEM_CRIANCAS)
        return ItemOrcamento("Desconto de 5% (sem crianças)", -valor)

    def descricao(self) -> str:
        criancas = "com crianças" if self.tem_criancas else "sem crianças"
        return f"{super().descricao()}, {criancas}"


class Casa(ImovelResidencial):
    TIPO = "Casa"
    ALUGUEL_BASE = Decimal("900.00")
    ADICIONAL_2_QUARTOS = Decimal("250.00")


class Estudio(Imovel):
    """Estúdio: aluguel fixo; estacionamento em pacote de 2 vagas + vagas extras."""

    TIPO = "Estúdio"
    ALUGUEL_BASE = Decimal("1200.00")
    PACOTE_VAGAS = Decimal("250.00")
    VAGAS_NO_PACOTE = 2
    VAGA_EXTRA = Decimal("60.00")

    def __init__(self, vagas: int):
        if vagas < 0:
            raise ValueError("Quantidade de vagas não pode ser negativa.")
        self.vagas = vagas

    def adicionais(self) -> list:
        if self.vagas == 0:
            return []
        itens = [ItemOrcamento(f"Pacote de estacionamento ({self.VAGAS_NO_PACOTE} vagas)",
                               dinheiro(self.PACOTE_VAGAS))]
        extras = self.vagas - self.VAGAS_NO_PACOTE
        if extras > 0:
            itens.append(ItemOrcamento(f"{extras} vaga(s) adicional(is) x R$ {str(self.VAGA_EXTRA).replace('.', ',')}",
                                       dinheiro(self.VAGA_EXTRA * extras)))
        return itens

    def descricao(self) -> str:
        return f"{self.TIPO} com {self.vagas} vaga(s) de estacionamento"
