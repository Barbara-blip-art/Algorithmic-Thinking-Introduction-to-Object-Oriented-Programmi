# RentSmart — Sistema de Orçamento de Locação (R.M Imóveis)

Aplicação em Python (POO) que calcula o orçamento de locação de apartamentos, casas e estúdios,
exibe um resumo detalhado e gera um CSV com a projeção dos 12 primeiros meses.

## Requisitos
- Python 3.10 ou superior (usa apenas a biblioteca padrão; **não precisa instalar nada**).

## Como executar
```bash
git clone <URL-DO-SEU-REPOSITORIO>
cd rentsmart
python main.py
```
Responda às perguntas no terminal. Ao final, o arquivo `projecao_12_meses.csv` é criado na pasta atual.

## Como rodar os testes
```bash
python testes.py
```

## Estrutura do projeto
| Arquivo | Responsabilidade |
|---|---|
| `imoveis.py` | Classes `Imovel` (abstrata), `ImovelResidencial`, `Apartamento`, `Casa`, `Estudio` — regras de preço |
| `orcamento.py` | Classe `Orcamento` (taxa, parcelas, resumo, projeção) e `ExportadorCSV` |
| `interface.py` | Entrada de dados e validações no terminal |
| `main.py` | Ponto de entrada (laço principal) |
| `testes.py` | Testes automáticos das regras de negócio |
| `exemplo_projecao_12_meses.csv` | Exemplo de CSV gerado |

## Regras implementadas
- **Aluguel-base:** apartamento 1 quarto R$ 700 · casa 1 quarto R$ 900 · estúdio R$ 1.200.
- **2 quartos:** apartamento +R$ 200 · casa +R$ 250.
- **Garagem (casa/apartamento):** +R$ 300/mês.
- **Estúdio:** pacote de 2 vagas R$ 250 + R$ 60 por vaga adicional.
- **Desconto:** 5% para apartamento de quem **não** tem crianças, aplicado sobre o aluguel já com os adicionais.
- **Taxa contratual:** R$ 2.000, mostrada separadamente, em 1 a 5 parcelas (a última parcela absorve eventuais centavos de diferença).

## Premissas adotadas
- No estúdio, 1 ou 2 vagas custam o pacote (R$ 250); a partir da 3ª vaga soma-se R$ 60 por vaga. 0 vagas = sem custo de estacionamento.
- As parcelas da taxa são cobradas nos primeiros meses do contrato (parcela 1 no mês 1, etc.), somadas ao aluguel na projeção.
- O CSV usa `;` como separador e vírgula decimal, para abrir corretamente no Excel em português.
