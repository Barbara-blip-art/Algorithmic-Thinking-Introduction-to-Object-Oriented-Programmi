# Roteiro do Vídeo Pitch (até 4 minutos)

Dica: ensaie uma vez com cronômetro. Fale em tom natural, sem ler palavra por palavra. Deixe o PDF (fluxograma), o VS Code com o projeto, o terminal e o CSV já abertos antes de gravar.

| Tempo | Tela | O que falar |
|---|---|---|
| 0:00-0:30 | Slide ou README | "Olá, eu sou [seu nome]. Este é o RentSmart, sistema que criei para a R.M Imóveis. Hoje os atendentes calculam orçamentos de locação na mão, o que demora e gera erros em adicionais e descontos. O RentSmart faz esse cálculo automaticamente e gera uma projeção de 12 meses em CSV." |
| 0:30-1:00 | Fluxograma (PDF) | "A lógica começa escolhendo o tipo de imóvel. Estúdio pergunta as vagas; casa e apartamento perguntam quartos e garagem, e o apartamento ainda pergunta se há crianças. Se for apartamento sem crianças, aplico 5% de desconto depois dos adicionais. Depois escolho as parcelas da taxa, mostro o resumo e gero o CSV." |
| 1:00-1:50 | VS Code: `imoveis.py` | "Usei POO. A classe abstrata `Imovel` define o contrato. `ImovelResidencial` guarda quartos e garagem, e `Apartamento` e `Casa` herdam dela, então a regra não se repete. `Apartamento` sobrescreve o método `desconto()`. `Estudio` herda direto de `Imovel` e tem sua regra de vagas." *(mostre `desconto()` e `Estudio.adicionais()`)* |
| 1:50-2:15 | VS Code: `orcamento.py` | "A classe `Orcamento` recebe um imóvel e chama `aluguel_mensal()` sem saber qual é o tipo: isso é polimorfismo. Ela também divide a taxa em parcelas, com a última ajustando os centavos, e monta a projeção. O `ExportadorCSV` só cuida de gravar o arquivo." |
| 2:15-3:15 | Terminal: `python main.py` | "Vou fazer um orçamento completo: apartamento, 2 quartos, com garagem, sem crianças, taxa em 3 parcelas." *(digite 1, 2, s, n, 3)* "O aluguel é 700 + 200 + 300 = 1.200, menos 5%, dá R$ 1.140. A taxa de R$ 2.000 aparece separada, em 3 parcelas. O total dos 12 meses é R$ 15.680." *(mostre também uma entrada inválida sendo recusada)* |
| 3:15-3:40 | Excel ou editor: CSV | "Este é o `projecao_12_meses.csv`: nos meses 1 a 3 o valor inclui a parcela da taxa, e do mês 4 ao 12 aparece só o aluguel." |
| 3:40-4:00 | Rodar `python testes.py` e fechar | "A POO deixou o código organizado: para mudar uma regra altero uma classe, e para criar um novo tipo de imóvel basta uma nova subclasse. Os testes automáticos confirmam as regras. Obrigado!" |

## Checklist antes de publicar
- Duração de **até 4:00**.
- Publicar no YouTube em modo **não listado** e testar o link em uma aba anônima.
- Colocar o link do vídeo e o do GitHub na entrega.
