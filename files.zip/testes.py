"""Testes automáticos das regras de negócio. Execute: python testes.py"""
import unittest
from decimal import Decimal as D

from imoveis import Apartamento, Casa, Estudio
from orcamento import Orcamento


class TestRegras(unittest.TestCase):
    def test_apartamento_1_quarto_com_criancas(self):
        self.assertEqual(Apartamento(1, False, True).aluguel_mensal(), D("700.00"))

    def test_apartamento_2_quartos_garagem_sem_criancas(self):
        # (700 + 200 + 300) = 1200 -> 5% de desconto = 1140
        self.assertEqual(Apartamento(2, True, False).aluguel_mensal(), D("1140.00"))

    def test_apartamento_1_quarto_sem_criancas(self):
        self.assertEqual(Apartamento(1, False, False).aluguel_mensal(), D("665.00"))

    def test_casa_1_quarto(self):
        self.assertEqual(Casa(1, False).aluguel_mensal(), D("900.00"))

    def test_casa_2_quartos_com_garagem_sem_desconto(self):
        self.assertEqual(Casa(2, True).aluguel_mensal(), D("1450.00"))

    def test_estudio_sem_vaga(self):
        self.assertEqual(Estudio(0).aluguel_mensal(), D("1200.00"))

    def test_estudio_pacote_2_vagas(self):
        self.assertEqual(Estudio(2).aluguel_mensal(), D("1450.00"))

    def test_estudio_4_vagas(self):
        self.assertEqual(Estudio(4).aluguel_mensal(), D("1570.00"))

    def test_parcelas_somam_taxa(self):
        for n in range(1, 6):
            self.assertEqual(sum(Orcamento(Casa(1, False), n).parcelas()), D("2000.00"))

    def test_projecao_12_meses(self):
        linhas = Orcamento(Casa(1, False), 5).projecao_12_meses()
        self.assertEqual(len(linhas), 12)
        self.assertEqual(linhas[-1]["acumulado"], D("12800.00"))  # 12*900 + 2000

    def test_validacoes(self):
        with self.assertRaises(ValueError):
            Casa(3, False)
        with self.assertRaises(ValueError):
            Orcamento(Casa(1, False), 6)
        with self.assertRaises(ValueError):
            Estudio(-1)


if __name__ == "__main__":
    unittest.main()
