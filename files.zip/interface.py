"""Interação com o usuário (entrada e validação). Não contém regras de preço."""
from imoveis import Apartamento, Casa, Estudio, Imovel
from orcamento import Orcamento

MAX_VAGAS_ESTUDIO = 10


def ler_opcao(pergunta: str, opcoes: dict) -> str:
    """Mostra um menu {chave: texto} e repete até o usuário escolher uma chave válida."""
    while True:
        print(f"\n{pergunta}")
        for chave, texto in opcoes.items():
            print(f"  {chave} - {texto}")
        resposta = input("Escolha: ").strip()
        if resposta in opcoes:
            return resposta
        print("Opção inválida. Tente novamente.")


def ler_inteiro(pergunta: str, minimo: int, maximo: int) -> int:
    while True:
        resposta = input(f"{pergunta} ({minimo} a {maximo}): ").strip()
        if resposta.isdigit() and minimo <= int(resposta) <= maximo:
            return int(resposta)
        print(f"Valor inválido. Digite um número inteiro entre {minimo} e {maximo}.")


def ler_sim_nao(pergunta: str) -> bool:
    while True:
        resposta = input(f"{pergunta} (s/n): ").strip().lower()
        if resposta in ("s", "sim"):
            return True
        if resposta in ("n", "nao", "não"):
            return False
        print("Responda com 's' ou 'n'.")


def montar_imovel() -> Imovel:
    """Pergunta o necessário para cada tipo e devolve o objeto Imovel correspondente."""
    tipo = ler_opcao("Qual tipo de imóvel?", {"1": "Apartamento", "2": "Casa", "3": "Estúdio"})
    if tipo == "3":
        vagas = ler_inteiro("Quantas vagas de estacionamento (0 = nenhuma)", 0, MAX_VAGAS_ESTUDIO)
        return Estudio(vagas)
    quartos = ler_inteiro("Quantos quartos", 1, 2)
    garagem = ler_sim_nao("Deseja vaga de garagem (+ R$ 300,00/mês)?")
    if tipo == "1":
        tem_criancas = ler_sim_nao("Há crianças que morarão no imóvel?")
        return Apartamento(quartos, garagem, tem_criancas)
    return Casa(quartos, garagem)


def montar_orcamento() -> Orcamento:
    imovel = montar_imovel()
    parcelas = ler_inteiro("Em quantas parcelas deseja pagar a taxa contratual de R$ 2.000,00",
                           1, Orcamento.MAX_PARCELAS)
    return Orcamento(imovel, parcelas)
